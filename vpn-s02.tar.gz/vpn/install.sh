#!/bin/bash

if [[ $(id -u) -ne 0 ]] ; then echo "please run as root" ; exit 1 ; fi

apt install -y openvpn
cp -p vpn-client-prg.service /etc/systemd/system/
systemctl start vpn-client-prg
systemctl enable vpn-client-prg

echo "done!"
