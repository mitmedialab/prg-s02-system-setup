#!/bin/sh

# as root:
openvpn --config /home/prg/vpn/robots-shared-s02-credentials@media.mit.edu.ovpn
